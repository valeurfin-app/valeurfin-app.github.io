# ValeurFin v4.1 — Complete Product Documentation

**Product, Functional & Technical Specification + Wireframes + KT Document**

April 2026 | CONFIDENTIAL — Internal Product Documentation

Owner: Siddharth Tiwari | valeurfin.masteryourfinances@gmail.com
Live URL: valeurfin-app.github.io/valeurfin

---

# TABLE OF CONTENTS

- Section 1 — Wireframes & UI Architecture
- Section 2 — Functional Specification  
- Section 3 — Technical Specification
- Section 4 — KT (Knowledge Transfer) Document

---

# SECTION 1 — WIREFRAMES & UI ARCHITECTURE

## 1.1 Application Structure Overview

ValeurFin ships as two separate single-HTML-file PWAs with 100% feature parity:

```
┌──────────────────────────────────────────────────────────────┐
│                    VALEURFIN APP STRUCTURE                    │
├─────────────────────────────┬────────────────────────────────┤
│   DESKTOP  (index.html)     │   MOBILE  (valeurfin-mobile)   │
│   5,573 lines               │   3,861 lines                  │
│   Sidebar navigation        │   Bottom tab navigation        │
│   Full-width table views    │   Card-based compact views     │
│   24 pages                  │   24 pages (same data)         │
│   269 functions             │   240 functions                │
│   Accessible at:            │   Accessible at:               │
│   /valeurfin                │   /valeurfin-mobile.html       │
│   Auto-redirects mobile     │   Auto-redirects desktop       │
│   Installable PWA           │   Installable PWA              │
├─────────────────────────────┼────────────────────────────────┤
│              SHARED SERVICE WORKER (sw.js)                    │
│              154 lines │ Network-First │ Auto-Update          │
│              Cache: valeurfin-v5i │ HTML no-cache bypass      │
└──────────────────────────────────────────────────────────────┘
```

## 1.2 Desktop Layout

```
┌──────────────────────────────────────────────────────────────────┐
│  TOPBAR                                                          │
│  [Page Title] [14 Apr 2026] [✨AI] [👤Member] [↗][📊][🔔3][🥇][📄][📄][🧮] │
├────────────────┬─────────────────────────────────────────────────┤
│  SIDEBAR       │  MAIN CONTENT AREA                              │
│  ┌──────────┐  │                                                 │
│  │ Logo     │  │  ┌──────────────────────────────────────────┐  │
│  │ ValeurFin│  │  │  PAGE CONTENT                            │  │
│  │ v4.1     │  │  │  (changes based on nav selection)        │  │
│  ├──────────┤  │  │                                          │  │
│  │ 👤 Name  │  │  │  Scrollable area                        │  │
│  │ Family   │  │  │                                          │  │
│  ├──────────┤  │  └──────────────────────────────────────────┘  │
│  │ [Family  │  │                                                 │
│  │  DD ▼]   │  │                                                 │
│  ├──────────┤  │                                                 │
│  │ Portfolio │  │                                                 │
│  │ 🏠 Dash   │  │                                                 │
│  │ 📈 Market │  │                                                 │
│  │ 📊 Invest │  │                                                 │
│  │ ➕ Add Inv│  │                                                 │
│  │ Tracking  │  │                                                 │
│  │ 💸 Expense│  │                                                 │
│  │ 💰 Income │  │                                                 │
│  │ ⏰ Remind │  │                                                 │
│  │ Planning  │  │                                                 │
│  │ 🎯 Goals  │  │                                                 │
│  │ 🛡️ Insure │  │                                                 │
│  │ Analytics │  │                                                 │
│  │ 🤖 Bot AI │  │                                                 │
│  │ 📐 KPIs   │  │                                                 │
│  │ 💰 Divid  │  │                                                 │
│  │ 🧮 SIP Cal│  │                                                 │
│  │ 📋 Log    │  │                                                 │
│  │ 🔍 Screen │  │                                                 │
│  │ 🧮 Tax    │  │                                                 │
│  │ 🚪 Exit   │  │                                                 │
│  │ 🔮 Project│  │  ← NEW: Wealth Projector                      │
│  │ Tools     │  │                                                 │
│  │ 📥 Import │  │                                                 │
│  │ Settings  │  │                                                 │
│  │ 🔒 Secur  │  │                                                 │
│  │ 👨‍👩‍👧 Family│  │                                                 │
│  │ 📜 Privacy│  │                                                 │
│  │ ⚖️ Terms  │  │                                                 │
│  │ 💎 About  │  │                                                 │
│  └──────────┘  │                                                 │
│  © 2026 Footer │                                                 │
└────────────────┴─────────────────────────────────────────────────┘
```

## 1.3 Mobile Layout

```
┌─────────────────────────────────────┐
│  TOPBAR                             │
│  [V] ValeurFin ✨AI  [🔄][🔔3][⚙️]│
├─────────────────────────────────────┤
│                                     │
│  CONTENT AREA (scrollable)          │
│                                     │
│  Changes based on active tab        │
│                                     │
├─────────────────────────────────────┤
│  BOTTOM NAV                         │
│  🏠Home  💼Inv  💸Exp  ➕Add  ⋯More│
└─────────────────────────────────────┘

More Menu (3-column grid):
┌──────────┬──────────┬───────────────┐
│📈 Market │💰 Income │⏰ Reminders   │
├──────────┼──────────┼───────────────┤
│🎯 Goals  │🛡️ Insure │🤖 Bot AI      │
├──────────┼──────────┼───────────────┤
│📐 KPIs   │💰 Divid. │🔮 What-If     │
├──────────┼──────────┼───────────────┤
│📋 Log    │🧮 Tax    │🚪 Exit Sig.   │
├──────────┼──────────┼───────────────┤
│🔮 Project│🔍 Screen │👨‍👩‍👧 Family     │ ← NEW: Projector tile
├──────────┼──────────┼───────────────┤
│🔒 Secure │📥 Import │💎 About       │
└──────────┴──────────┴───────────────┘
```

## 1.4 Dashboard / Home Page (Updated)

```
┌───────────────────────────────────────────────────────────┐
│  Dashboard                   14 Apr 2026  ✨AI  👤All    │
├───────────────────────────────────────────────────────────┤
│  ⚠ Disclaimer: Educational tool. Not financial advice.   │
├───────────────────────────────────────────────────────────┤
│  VIEWING PORTFOLIO FOR                                    │
│  [👨‍👩‍👧‍👦 All Family] [👤 Siddharth] [👤 Sam] [👤 Lam]    │
├─────────────────────┬─────────────────────────────────────┤
│  HERO CARD          │  STATS ROW                          │
│  TOTAL NET WORTH    │  ┌──────┬──────┬──────┬──────────┐ │
│  ₹ X,XX,XXX  ● LIVE│  │SIP/mo│Spend │Saving│Invested  │ │
│  +₹XX,XXX (+X.X%)  │  │₹X,XXX│₹X,XXX│XX.X% │₹X,XX,XXX│ │
│  Wealth Score: XX   │  └──────┴──────┴──────┴──────────┘ │
│                     │                                      │
│  (When member view: │                                      │
│   SID'S NET WORTH)  │                                      │
├─────────────────────┴─────────────────────────────────────┤
│                                                           │
│  ┌─ 🔮 Estimated Net Worth (1Y) ──── [Explore →] ──────┐ │ ← NEW
│  │  ESTIMATED        AFTER TAX        INFLATION ADJ.    │ │
│  │  ₹XX,XX,XXX      ₹XX,XX,XXX      ₹XX,XX,XXX        │ │
│  │                                                      │ │
│  │  📈 SIP   ₹3.1L → ₹4.2L                            │ │
│  │  📊 Stocks ₹5.2L → ₹5.8L                           │ │
│  │  🏦 FD    ₹2.0L → ₹2.14L                           │ │
│  │  🏛️ PPF   ₹1.0L → ₹1.07L                           │ │
│  │  🏛️ NPS   ₹0.8L → ₹0.88L                           │ │
│  └──────────────────────────────────────────────────────┘ │
│                                                           │
│  ┌─ 👨‍👩‍👧‍👦 Family Overview ────────────────────────────────┐ │
│  │ ┌────────────┐ ┌────────────┐ ┌────────────┐        │ │
│  │ │ Siddharth  │ │ Sam        │ │ Lam        │        │ │
│  │ │ ₹X.XL NW  │ │ ₹X.XL NW  │ │ ₹X.XL NW  │        │ │
│  │ │ +X.X%      │ │ +X.X%      │ │ +X.X%      │        │ │
│  │ │ N invest.  │ │ N invest.  │ │ N invest.  │        │ │
│  │ └────────────┘ └────────────┘ └────────────┘        │ │
│  └──────────────────────────────────────────────────────┘ │
│                                                           │
│  ┌─ 📈 Market Overview ──── LIVE ─────────────────────┐  │
│  │  NIFTY 50  XX,XXX  ▲X.X%   SENSEX  XX,XXX  ▲X.X%  │  │
│  └────────────────────────────────────────────────────┘  │
│                                                           │
│  ┌─ 💰 Cash Flow ────────────────────────────────────┐   │
│  │  Income ₹XX,XXX │ Expenses ₹XX,XXX │ SIP ₹X,XXX  │   │
│  └───────────────────────────────────────────────────┘   │
│                                                           │
│  ┌─ 🔥 FIRE Progress ─────────────┐                     │
│  │  FI Number: ₹X.XCr             │                     │
│  │  Progress: XX.X%               │                     │
│  │  ████████████░░░░░             │                     │
│  └─────────────────────────────────┘                     │
│                                                           │
│  ┌─ ↗ Net Worth History ──────────────────────────────┐  │
│  │  Apr23  Aug23  ...  Dec25  Apr26  (sparkline)      │  │
│  └────────────────────────────────────────────────────┘  │
│                                                           │
│  ┌─ ◑ Asset Allocation ─────┐ ┌─ ▤ Sector Allocation ─┐ │
│  │  Equity   XX% ████████   │ │  Banking XX% ████████  │ │
│  │  Debt     XX% █████      │ │  IT      XX% ██████    │ │
│  │  Alts     XX% ███        │ │  FMCG    XX% ████      │ │
│  └──────────────────────────┘ └────────────────────────┘ │
│                                                           │
│  ┌─ ✨ AI Insights ──────────────────────────────────┐   │
│  │  💡 Equity allocation 78% — above safe limit      │   │
│  │  💡 3 SIPs due this week                          │   │
│  │  💡 FD maturing in 12 days                        │   │
│  └───────────────────────────────────────────────────┘   │
│                                                           │
│  ┌─ 💸 Monthly Expenses ────┐ ┌─ ≡ Top Holdings ──────┐ │
│  │  Rent    ₹25K ████████   │ │  HDFC Bank  ₹2.7L     │ │
│  │  Grocery ₹8K  ████       │ │  Rel.Ind    ₹1.5L     │ │
│  └──────────────────────────┘ └────────────────────────┘ │
│                                                           │
│  ┌─ 🚪 Exit Cues ───────────────────────────────────┐   │
│  │  🟢 HDFC Bank — Continue holding                  │   │
│  │  🟡 ITC — Near 52W low, review position           │   │
│  └───────────────────────────────────────────────────┘   │
│                                                           │
│  ┌─ 📰 Market News ─────────────────────────────────┐   │
│  │  Latest headlines from RSS feeds                  │   │
│  └───────────────────────────────────────────────────┘   │
│                                                           │
│  ┌─ 🔔 Recent Alerts ───────────────────────────────┐   │
│  │  ⏰ HDFC SIP Due — ₹5,000 — Tomorrow             │   │
│  │  🛡️ LIC Premium — ₹15,000/yr — 3 days            │   │
│  └───────────────────────────────────────────────────┘   │
└───────────────────────────────────────────────────────────┘
```

## 1.5 Add Investment Page (Updated — Stocks Form)

```
┌──────────────────────────────────────────────────┐
│  ➕ Add New Investment                           │
│  Select type and fill details                    │
│  * Required fields for Stocks                    │
├──────────────────────────────────────────────────┤
│  TYPE SELECTOR (horizontal pills)                │
│  [📈SIP] [📊Stocks] [🏦FD] [🏦RD] [🏛PPF]      │
│  [🏛NPS] [🥇Gold] [₿Crypto] [🏠Land] [📈ELSS]  │
│  [📄Bonds] [📋Others]                            │
├──────────────────────────────────────────────────┤
│                                                  │
│  === STOCKS FORM (exact field order) ===         │
│                                                  │
│  1. NAME            [_____Search dropdown_____]  │
│                     (140+ NSE stock database)    │
│                                                  │
│  2. PLATFORM [Groww ▼]   3. STARTED [__/__/____] │
│                                                  │
│  (No Current Value field for Stocks)             │
│                                                  │
│  5. NSE SYMBOL      [HDFCBANK________]           │
│     ── ✅ Found: ₹1,820.45 ▲0.42% ──           │
│                                                  │
│  6. SECTOR          [Banking ▼]                  │
│                                                  │
│  7. QTY *           [10____]                     │
│  8. BUY PRICE *     [₹1,650]                    │
│                                                  │
│  9. INVESTED AMOUNT     [auto = 10 × 1650]       │
│     (₹16,500 — auto, editable)                  │
│                                                  │
│  10. CURRENT STOCK PRICE [₹1,820.45]             │
│      (auto-fetched, editable)                    │
│                                                  │
│  11. CURRENT VALUE       [auto = 10 × 1820.45]   │
│      (₹18,204.50 — auto, editable)              │
│                                                  │
│  12. RETURN %            [— XIRR calculated]     │
│      (read-only display)                         │
│                                                  │
│  OWNER              [Siddharth ▼]                │
│  (only in family mode)                           │
│                                                  │
│  ┌─ Previous Purchases (optional) ─────────────┐ │
│  │ [Date____] [Qty___] [Price___] [+ Add]      │ │
│  │ Lot 1: 10 Mar 2023 — 10 qty @ ₹1,600       │ │
│  │ Lot 2: 20 Oct 2024 — 20 qty @ ₹1,750   [×] │ │
│  └─────────────────────────────────────────────┘ │
│                                                  │
│              [💾 Save Investment]                │
└──────────────────────────────────────────────────┘
```

## 1.6 Add Investment — SIP / ELSS Form

```
┌──────────────────────────────────────────────────┐
│  TYPE: [📈 SIP (Mutual Fund)] selected           │
├──────────────────────────────────────────────────┤
│  FUND NAME          [___type to search___] 🔍    │
│  (searches mfapi.in + local DB of 120+ funds)    │
│  ┌──────────────────────────────────────────────┐│
│  │ HDFC Balanced Advantage Fund - Growth  ✓     ││
│  │ HDFC Flexi Cap Fund - Growth                 ││
│  │ HDFC Mid-Cap Opportunities - Growth          ││
│  └──────────────────────────────────────────────┘│
│                                                  │
│  PLATFORM [Groww ▼]     STARTED [__/__/____]     │
│  CURRENT VALUE (₹)      [85,607___]              │
│                                                  │
│  TOTAL UNITS HELD        [2456.789__]            │
│  (from broker/CAMS)                              │
│  SCHEME CODE             [118989] (auto-filled)  │
│                                                  │
│  MONTHLY SIP (₹)  [5,000]   DUE DATE [10th ▼]   │
│                                                  │
│  ANNUAL STEP-UP    [10% per year ▼]              │
│  (No Step-Up / 5% / 10% / 15% / 20% / Custom)   │
│                                                  │
│  STEP-UP FROM      [After Year 1 ▼]             │
│  (From Start / After Year 1/2/3)                 │
│                                                  │
│  OWNER             [Siddharth ▼]                 │
│                                                  │
│              [💾 Save Investment]                │
└──────────────────────────────────────────────────┘
```

## 1.7 Add Investment — RD Form (Updated)

```
┌──────────────────────────────────────────────────┐
│  TYPE: [🏦 Recurring Deposit] selected           │
├──────────────────────────────────────────────────┤
│  NAME               [ICICI RD_________]          │
│  PLATFORM [ICICI Bank ▼]  STARTED [__/__/____]   │
│  CURRENT VALUE (₹)  [50,000___]                  │
│                                                  │
│  MONTHLY AMOUNT (₹) [2,500]  DUE DATE [1st ▼]   │
│  ← Label: "Monthly Amount" NOT "Monthly SIP"     │
│  ← No Step-Up fields (removed for RD)            │
│                                                  │
│  MATURITY    [__/__/____]  INTEREST % [7.5]      │
│  OWNER       [Siddharth ▼]                       │
│              [💾 Save Investment]                │
└──────────────────────────────────────────────────┘
```

## 1.8 Add Investment — PPF Form (Updated)

```
┌──────────────────────────────────────────────────┐
│  TYPE: [🏛️ PPF] selected                         │
├──────────────────────────────────────────────────┤
│  NAME               [PPF - SBI_________]         │
│  PLATFORM [SBI ▼]        STARTED [__/__/____]    │
│  CURRENT VALUE (₹)  [__________]                 │
│                                                  │
│  CURRENT BALANCE (₹)    [10,00,000]              │
│  RATE OF INTEREST %     [7.1] (editable)         │
│                                                  │
│  ┌─────────────────────────────────────────────┐ │
│  │ 🏛️ PPF: Annual compound interest.           │ │
│  │ Tax exempt under Section 80C.               │ │
│  │ Update balance yearly.                      │ │
│  └─────────────────────────────────────────────┘ │
│                                                  │
│  ← No Monthly SIP fields                        │
│  ← No Step-Up fields                            │
│  ← No Due Date                                  │
│  ← hasMonthly: false in INV_TYPES               │
│                                                  │
│  OWNER       [Siddharth ▼]                       │
│              [💾 Save Investment]                │
└──────────────────────────────────────────────────┘
```

## 1.9 Add Investment — NPS Form (Updated)

```
┌──────────────────────────────────────────────────┐
│  TYPE: [🏛️ NPS] selected                         │
├──────────────────────────────────────────────────┤
│  NAME               [NPS - HDFC_______]          │
│  PLATFORM [HDFC Pension ▼]  STARTED [__/__/____] │
│  CURRENT VALUE (₹)  [__________]                 │
│                                                  │
│  CURRENT BALANCE (₹)    [5,00,000]               │
│  EXPECTED RETURN %       [10] (editable)         │
│                                                  │
│  ┌─────────────────────────────────────────────┐ │
│  │ 🏛️ NPS: 60% tax-free on maturity.           │ │
│  │ Update balance yearly.                      │ │
│  └─────────────────────────────────────────────┘ │
│                                                  │
│  ← No Monthly SIP fields                        │
│  ← hasMonthly: false in INV_TYPES               │
│                                                  │
│  OWNER       [Siddharth ▼]                       │
│              [💾 Save Investment]                │
└──────────────────────────────────────────────────┘
```

## 1.10 Add Investment — Gold Form

```
┌──────────────────────────────────────────────────┐
│  TYPE: [🥇 Gold / SGB] selected                  │
├──────────────────────────────────────────────────┤
│  NAME               [Gold Biscuit 24K__]         │
│  PLATFORM [Manual ▼]    STARTED [__/__/____]     │
│  CURRENT VALUE (₹)  [__________]                 │
│                                                  │
│  WEIGHT (grams)     [10.5] (enables live price)  │
│  PURITY             [22K (916 / Hallmark) ▼]     │
│  (24K / 22K / 18K / SGB-ETF)                    │
│                                                  │
│  INVESTED (₹) [________]  RETURN % [____]        │
│  OWNER       [Siddharth ▼]                       │
│              [💾 Save Investment]                │
└──────────────────────────────────────────────────┘
```

## 1.11 Wealth Projector Page (NEW)

```
┌───────────────────────────────────────────────────────────┐
│  🔮 Wealth Projector  [Estimated]                         │
│  Project your net worth over time — with tax & inflation  │
├───────────────────────────────────────────────────────────┤
│  TIME HORIZON                                             │
│  [1Y] [3Y] [5Y] [10Y] [15Y] [20Y]                       │
├───────────────────────────────────────────────────────────┤
│  VIEWING PORTFOLIO FOR                                    │
│  [👨‍👩‍👧‍👦 All Family] [👤 Siddharth] [👤 Sam] [👤 Lam]    │
├───────────────────────────────────────────────────────────┤
│  INFLATION RATE %  [6___]     GOLD GROWTH %  [8___]      │
│                                                           │
│  EXPECTED RATE OF RETURN %  [____] (optional override)    │
│  (Leave blank for auto calculation per asset type)        │
├───────────────────────────────────────────────────────────┤
│                                                           │
│  ┌──────────────────────────────────────────────────────┐│
│  │  ESTIMATED NET WORTH (5Y)                ₹28,45,000 ││
│  │  +₹15,45,000 from today                             ││
│  ├──────────────────────────────────────────────────────┤│
│  │  AFTER TAX          │  INFLATION ADJ.  │  REAL VALUE ││
│  │  ₹26,12,000         │  ₹21,26,000      │  ₹19,53,000││
│  │  -₹2,33,000 tax     │  at 6% inflation │  purch.power││
│  └──────────────────────────────────────────────────────┘│
│                                                           │
│  TYPE BREAKDOWN                                           │
│  📈 SIP       ₹3.1L → ₹5.8L   (+87.1%)                 │
│  📊 Stocks    ₹5.2L → ₹8.4L   (+61.5%)                 │
│  🏦 FD        ₹2.0L → ₹2.8L   (+40.0%)                 │
│  🏛️ PPF       ₹1.0L → ₹1.41L  (+41.0%)                 │
│  🏛️ NPS       ₹0.8L → ₹1.29L  (+61.1%)                 │
│  🥇 Gold      ₹0.4L → ₹0.59L  (+47.0%)                 │
│                                                           │
│  YEAR-BY-YEAR PROJECTION                                  │
│  ┌──────┬──────────┬─────────┬────────┬────────┬────────┬────────┐
│  │ Year │ Est.Value│ Growth  │Est.Tax │Aft.Tax │Infl.Adj│Real Val│
│  ├──────┼──────────┼─────────┼────────┼────────┼────────┼────────┤
│  │ Yr 1 │ ₹15.2L   │ +₹2.2L  │ ₹0.3L  │ ₹14.9L │ ₹14.3L │ ₹14.1L │
│  │ Yr 2 │ ₹17.8L   │ +₹4.8L  │ ₹0.7L  │ ₹17.1L │ ₹15.8L │ ₹15.2L │
│  │ Yr 3 │ ₹20.8L   │ +₹7.8L  │ ₹1.2L  │ ₹19.6L │ ₹17.4L │ ₹16.4L │
│  │ Yr 4 │ ₹24.2L   │ +₹11.2L │ ₹1.8L  │ ₹22.4L │ ₹19.2L │ ₹17.7L │
│  │ Yr 5 │ ₹28.4L   │ +₹15.4L │ ₹2.3L  │ ₹26.1L │ ₹21.3L │ ₹19.5L │
│  └──────┴──────────┴─────────┴────────┴────────┴────────┴────────┘
│  (Mobile: 5 columns — Yr, Value, Tax, After Tax, Real)   │
└───────────────────────────────────────────────────────────┘
```

## 1.12 Insurance Page (Updated)

```
┌──────────────────────────────────────────────────┐
│  🛡️ Insurance                     [+ Add Policy] │
├──────────────────────────────────────────────────┤
│  SCORE RING                                      │
│  ┌─────────┐                                    │
│  │   72    │  Good — missing critical illness    │
│  │  /100   │                                     │
│  └─────────┘                                    │
├──────────────────────────────────────────────────┤
│  POLICY LIST                                     │
│  ┌──────────────────────────────────────────────┐│
│  │ 🏥 HDFC Ergo Health    ACTIVE                ││
│  │ Health · HDFC Ergo                           ││
│  │ Sum: ₹10,00,000    Premium: ₹15,000/yr      ││
│  │                     Due 15th Mar              ││ ← NEW
│  └──────────────────────────────────────────────┘│
│                                                  │
│  ADD INSURANCE MODAL (Updated):                  │
│  ┌──────────────────────────────────────────────┐│
│  │ Policy Name  [__________]                    ││
│  │ Type [Term Life ▼]  Company [HDFC Ergo ▼]    ││
│  │ Sum Assured  [10,00,000]  Premium [15,000]   ││
│  │ Frequency [Annually ▼]    Status [Active ▼]  ││
│  │                                              ││
│  │ Premium Due Day    [15th ▼]  ← NEW           ││
│  │ Premium Due Month  [Mar ▼]   ← NEW           ││
│  │ (enables 3-day advance alerts)               ││
│  └──────────────────────────────────────────────┘│
└──────────────────────────────────────────────────┘
```

## 1.13 Investments Table Page

```
┌────────────────────────────────────────────────────────────────┐
│  📊 Investments  [4]  [● LIVE]     [Fetching prices... ×]     │
├────────────────────────────────────────────────────────────────┤
│  [All] [SIP] [Stocks] [FD] [RD] [PPF] [NPS] [Gold]           │
├──────┬──────────┬────────┬────────┬─────┬────────┬──────┬─────┬──────┬───────┤
│ NAME │ PLATFORM │INVESTED│CURRENT │ LIVE│RETURNS │ XIRR │SECTOR│ TAX │SIGNAL │OWNER │
├──────┼──────────┼────────┼────────┼─────┼────────┼──────┼─────┼──────┼───────┤
│HDFC  │ Groww    │₹50.0K  │₹79.4K  │₹794 │+₹29.4K │ 0.0% │Bank │ STCG │  📊   │ sid  │
│Bank  │Stocks    │        │        │.05  │+58.8%  │      │     │      │       │      │
├──────┼──────────┼────────┼────────┼─────┼────────┼──────┼─────┼──────┼───────┤
│ITC   │ Groww    │₹17.1K  │₹29.9K  │₹298 │+₹12.8K │12.5% │FMCG │ LTCG │  📊   │ sid  │
│      │Stocks    │        │        │.65  │+74.6%  │      │     │      │       │      │
└──────┴──────────┴────────┴────────┴─────┴────────┴──────┴─────┴──────┴───────┘
│  Actions per row: ✏️ Edit  📊 Screener.in  📈 Tickertape  🗑️ Delete           │
└────────────────────────────────────────────────────────────────────────────────┘
```

## 1.14 Dividends Page

```
┌──────────────────────────────────────────────────────┐
│  💰 Dividends  [Auto]               [+ Add Dividend] │
├──────────────────────────────────────────────────────┤
│  TOTAL DIVIDENDS  ₹X,XXX │ FROM HOLDINGS ₹X,XXX     │
├──────────────────────────────────────────────────────┤
│  📊 From Your Holdings [Auto]                        │
│  ┌──────┬──────────┬─────────┬──────────┬──────────┐│
│  │Stock │ Payments │ Last DPS│ Last Date│ Your Tot ││
│  ├──────┼──────────┼─────────┼──────────┼──────────┤│
│  │HDFC  │ 5        │ ₹19.50  │2024-07-18│ ₹2,850   ││
│  │ITC   │ 8        │ ₹6.75   │2025-01-22│ ₹1,350   ││
│  └──────┴──────────┴─────────┴──────────┴──────────┘│
│                                                      │
│  🔮 AI Forecast (Next Dividend Prediction)           │
│  HDFC Bank: ~₹20/share in Jul 2026 (85% confidence) │
│                                                      │
│  Loading states:                                     │
│  - divCacheDate=0: "🔄 Loading dividend history..."  │
│  - divCacheDate=1: "⚠️ Unavailable [🔄 Retry]"      │
│  - divCacheDate>1: Shows data table                  │
└──────────────────────────────────────────────────────┘
```

## 1.15 Other Pages (Brief Wireframes)

### Expenses Page
```
┌──────────────────────────────────────────────────┐
│  💸 Expenses         [+ Add Expense]              │
│  MONTHLY: ₹XX,XXX                                │
│  ┌──────────────────────────────────────────────┐│
│  │ 🛒 Groceries    Monthly  ₹8,000      🗑️     ││
│  │ 🏠 Rent         Monthly  ₹25,000     🗑️     ││
│  │ 🚗 EMI          Monthly  ₹12,000     🗑️     ││
│  └──────────────────────────────────────────────┘│
└──────────────────────────────────────────────────┘
```

### Goals Page
```
┌──────────────────────────────────────────────────┐
│  🎯 Goals            [+ Add Goal]                 │
│  ┌──────────────────────────────────────────────┐│
│  │ 🏠 House Down Payment                        ││
│  │ Target: ₹15,00,000  Current: ₹3,50,000      ││
│  │ ████████░░░░░░░░░░░░░░░░░░░░  23.3%         ││
│  │ Deadline: Dec 2028                           ││
│  └──────────────────────────────────────────────┘│
└──────────────────────────────────────────────────┘
```

### Tax Calculator Page
```
┌──────────────────────────────────────────────────┐
│  🧮 Tax Calculator  [FY 2025-26]                  │
│  ┌──────────────────────────────────────────────┐│
│  │  TOTAL GAINS      STCG TAX       LTCG TAX   ││
│  │  ₹X,XX,XXX       ₹XX,XXX        ₹XX,XXX    ││
│  ├──────┬────────┬────────┬──────┬──────┬───────┤│
│  │ Name │Invested│Current │ Gain │ Type │  Tax  ││
│  ├──────┼────────┼────────┼──────┼──────┼───────┤│
│  │ HDFC │₹50K    │₹79K    │₹29K  │ STCG │₹5,800││
│  └──────┴────────┴────────┴──────┴──────┴───────┘│
└──────────────────────────────────────────────────┘
```

### Exit Signals Page
```
┌──────────────────────────────────────────────────┐
│  🚪 Exit Signals & Cues                          │
│  ┌──────────────────────────────────────────────┐│
│  │ 🟢 HOLD    HDFC Bank   Continue holding      ││
│  │ 🟡 REVIEW  ITC         Near 52-week low      ││
│  │ 🔴 SELL    SBI FD      FD matured—reinvest   ││
│  └──────────────────────────────────────────────┘│
└──────────────────────────────────────────────────┘
```

### Screener Page
```
┌──────────────────────────────────────────────────┐
│  🔍 Screener  [Portfolio]                         │
│  [All Types ▼]  [All Signals ▼]  [Value ↓ ▼]     │
│  SUMMARY: Count:5  Invested:₹4.2L  Current:₹4.8L │
│  ┌──────┬────────┬────────┬────────┬──────────┐  │
│  │ Type │ Name   │Invested│ Return │ Signal   │  │
│  ├──────┼────────┼────────┼────────┼──────────┤  │
│  │ 📊   │ HDFC   │ ₹2.4L  │ +13.2% │ 🟢 Hold  │  │
│  └──────┴────────┴────────┴────────┴──────────┘  │
└──────────────────────────────────────────────────┘
```

### Security Page
```
┌──────────────────────────────────────────────────┐
│  🔒 Security & Data Protection                   │
│  ┌──────┬──────┬──────┬──────┬──────┬──────┐    │
│  │📱    │🚫    │🛡️    │♻️    │💾    │🗑️    │    │
│  │Local │Zero  │PIN   │Export│Quad  │Wipe  │    │
│  │      │Server│Lock  │      │Store │      │    │
│  └──────┴──────┴──────┴──────┴──────┴──────┘    │
│  [🔑 PIN] [❓ SecQ] [📤 Export] [📥 Import]     │
│  [🚪 Sign Out]  [🗑️ Delete Account]             │
└──────────────────────────────────────────────────┘
```

---

END OF SECTION 1 — WIREFRAMES

---

# SECTION 2 — FUNCTIONAL SPECIFICATION

This section describes every feature from the user's perspective — what it does, how it behaves, and what the user can expect. Written for product owners, QA testers, support staff, and non-technical stakeholders.

## 2.1 Product Overview

| Property | Value |
|----------|-------|
| Product Name | ValeurFin |
| Version | 4.1 |
| Platform | Web PWA (Progressive Web App) — Desktop + Mobile |
| Language | Vanilla JavaScript, HTML5, CSS3 (no frameworks) |
| Data Storage | 100% on-device — IndexedDB + localStorage + sessionStorage + Cookie |
| Server Required | None — fully client-side |
| Internet Required | Only for live prices, MF NAV, gold price, market news, optional Gemini AI |
| Cost | Free — no subscription, no ads, no account required |
| Live URL | valeurfin-app.github.io/valeurfin |
| Supported Currency | Indian Rupee (₹) only |
| Target Users | Indian retail investors managing personal/family wealth |
| Desktop File | index.html (5,573 lines) |
| Mobile File | valeurfin-mobile.html (3,861 lines) |
| Service Worker | sw.js (154 lines) |
| Total Functions | 269 (desktop) / 240 (mobile) |
| Total Pages | 24 |
| Feature Parity | 100% desktop ↔ mobile |

## 2.2 Investment Tracking

### 2.2.1 Supported Investment Types (12 types)

| Type | Category | Live Price | Monthly SIP | Special Fields |
|------|----------|-----------|-------------|----------------|
| SIP (Mutual Fund) | Equity | NAV via mfapi.in | Yes | Units, Scheme Code, Step-Up |
| Stocks / ETF | Equity | Yahoo Finance | No | QTY, Buy Price, Lots, NSE Symbol, Sector |
| Fixed Deposit (FD) | Debt | Calculated | No | Maturity Date, Interest Rate |
| Recurring Deposit (RD) | Debt | Calculated | Yes (Monthly Amount) | Maturity Date, Interest Rate, No Step-Up |
| PPF | Debt | Calculated | No (hasMonthly: false) | Current Balance, Rate of Interest (default 7.1%) |
| NPS | Hybrid | Calculated | No (hasMonthly: false) | Current Balance, Expected Return (default 10%) |
| Gold / SGB | Alternatives | gold-api.com | No | Weight (grams), Purity (24K/22K/18K/SGB) |
| Crypto | Alternatives | No | No | Standard fields only |
| Real Estate / Land | Alternatives | No | No | Standard fields only |
| ELSS (Tax Saver) | Equity | NAV via mfapi.in | Yes | Units, Scheme Code, Step-Up |
| Bonds / Debentures | Debt | No | No | Standard fields only |
| Others | Alternatives | No | No | Standard fields only |

### 2.2.2 Lot-Based Stock Tracking

For Stocks and ETFs, users can record multiple purchase transactions (lots). The app automatically calculates:
- Total quantity = sum of all lot quantities
- Weighted average price = Σ(qty × price) ÷ total qty
- Total invested = Σ(qty × price) across all lots
- Current value = total qty × live market price
- XIRR = true cashflow XIRR using Newton-Raphson algorithm with each lot as a separate cash outflow

### 2.2.3 Mutual Fund Tracking (SIP / ELSS)

- User enters total units held (from broker/CAMS statement)
- Scheme code auto-filled when searching and selecting a fund
- Current value = total units × current NAV (fetched from mfapi.in)
- Fund search: queries mfapi.in via CORS proxy + local DB of 120+ popular Indian funds as fallback

### 2.2.4 PPF Tracking (Updated v4.1)

- PPF is NOT a monthly investment — hasMonthly is false
- User enters current accumulated balance (total corpus)
- Rate of interest editable (default 7.1%)
- Value calculated via annual compound: invested × (1 + rate)^years
- Tax: Fully exempt under Section 80C (EEE status)
- User should update balance yearly with new contributions + interest

### 2.2.5 NPS Tracking (Updated v4.1)

- NPS is NOT a monthly investment — hasMonthly is false
- User enters current accumulated corpus
- Expected return editable (default 10%)
- Value calculated via annual compound
- Tax: 60% of corpus tax-free on maturity, 40% taxable as annuity
- User should update balance yearly

### 2.2.6 RD Form (Updated v4.1)

- Label says "Monthly Amount" (not "Monthly SIP")
- No Step-Up fields (removed — RDs have fixed monthly deposits)
- Due Date + Maturity Date + Interest Rate still available
- Value calculated via monthly compound interest formula

### 2.2.7 Live Price Fetching

**Stock Prices (Yahoo Finance):**
- Tries SYMBOL.NS (NSE) first, then SYMBOL.BO (BSE) fallback
- 5 CORS proxy fallback chain: valeurfin.workers.dev → corsproxy.io → allorigins.win → codetabs.com → thingproxy
- Returns: price, previousClose, dayChange, dayChangePct, fiftyTwoHigh, fiftyTwoLow
- Symbol validator: 🔍 button tests symbol and shows live price + exchange

**Mutual Fund NAV (mfapi.in):**
- Endpoint: api.mfapi.in/mf/{schemeCode}/latest
- TTL: 8 hours (MF_NAV_STALE_MS)
- Updates inv.currentNAV; value = totalUnits × currentNAV

**Gold Price (gold-api.com):**
- Endpoint: gold-api.com/price/XAU?currency=INR
- TTL: 4 hours (GOLD_STALE_MS)
- Returns price per gram for 24K, 22K, 18K
- Auto-updates Gold investments where grams > 0

### 2.2.8 Auto-Refresh During Market Hours

- NSE market hours: 9:15 AM to 3:30 PM IST, Monday-Friday
- Watchdog pattern: 60-second timer checks if market has opened
- Once market opens: fires refreshAll() immediately, then every 5 minutes (AUTO_REFRESH_INTERVAL)
- Market closes: timer stops automatically
- Tab focus (visibilitychange): checks if data is stale, refreshes if needed
- Works even if app is opened before market hours — watchdog catches the opening

## 2.3 Automatic SIP Processing

- On every app open and refresh, checkAndProcessSIPs() runs
- For each investment with monthly > 0 and dueDate set:
  - Guard 1: Already processed this calendar month? (lastSIPMonth check) → skip
  - Guard 2: Today's date < due date? → skip
  - Process: adds monthly amount to invested + value, stamps lastSIPMonth
- Step-up: if stepUp > 0, monthly amount increases annually
- Duplicate protection: lastSIPMonth = "2026-04" prevents re-processing

### Edge Cases

| Scenario | Behaviour |
|----------|-----------|
| Due date = 31st, month has 28 days | Processes on 28th (last day) |
| User opens app twice on due date | Processes only once — lastSIPMonth guard |
| User misses opening on due date | Processes on next open (same month) |
| Step-up configured at 10% | Monthly amount × 1.1 per year from stepUpFrom month |

## 2.4 Dividend Tracking

### Auto-Fetched Dividends (NEW)
- Fetches 10-year dividend history from Yahoo Finance for all stocks with NSE symbols
- Per-investment cache: inv.divCache[] + inv.divCacheDate
- TTL: 24 hours (DIV_CACHE_MS)
- Three loading states:
  - divCacheDate = 0: "🔄 Loading dividend history..." (never tried)
  - divCacheDate = 1: "⚠️ Unavailable — proxy busy [🔄 Retry]" (all proxies failed)
  - divCacheDate > 1: Shows data table (successful fetch)
- AI Forecast: predictNextDividend() analyzes payment history to predict next dividend date, amount, frequency, and confidence level

### Manual Dividends
- Select stock from dropdown, enter date + DPS (dividend per share)
- Auto-calculates shares held on that date using lot history (getQtyOnDate)
- Total = qty held × DPS

## 2.5 Returns & XIRR Calculation

| Investment Type | Returns Formula | XIRR Method |
|----------------|----------------|-------------|
| Stocks (lot-based) | Value − Σ(qty × price per lot) | True cashflow XIRR — Newton-Raphson on each lot date+amount |
| Stocks (no lots) | Live Value − Invested | Simplified: (val/inv)^(12/months) − 1 |
| SIP / MF | Units × NAV − Invested | Simplified using start date |
| FD | Compound interest at rate | Uses configured return rate |
| RD | Monthly compound interest | Uses configured return rate |
| PPF | Annual compound at 7.1% | Uses configured return rate |
| NPS | Annual compound at 10% | Uses configured return rate |
| Gold | grams × live price − invested | No XIRR (manual tracking) |

## 2.6 Family Portfolio Mode (Updated v4.1)

### Setup
- Set during onboarding Step 2: "Individual" or "Family"
- Stored as S.user.mode ("individual" or "family")
- Family members: S.family[] = [{ id, name, relation, age }]
- Add members during onboarding or later from Family page

### Member Switching (3 ways)
1. **Dashboard pills** — "All Family" / "Siddharth" / "Sam" / "Lam" — top of dashboard
2. **Sidebar dropdown** — below user name in sidebar (desktop)
3. **Topbar indicator** — "👨‍👩‍👧‍👦 All" next to page title — click for popup

### How It Works
- All three call switchMember(val) → sets currentMember → calls renderAll()
- Every render function uses filterByMember(arr) which:
  - currentMember === "all" → returns full array
  - currentMember === "self" → returns items where owner === "self"
  - currentMember === memberId → returns items where owner === memberId
- Dashboard hero card shows "SID'S NET WORTH" when viewing a specific member

### Technical: No Length Guards
- All family UI renders based on S.user.mode === "family" only
- Works even with zero added members (just "All" + "You" pills)
- Functions affected: renderFamilyDD, renderMemberPills, showMemberSwitcher, rFamilyOverview, initApp

### Family on Wealth Projector (NEW)
- Wealth Projector page has its own member pills
- Switching members recalculates all projections for that member
- renderAll() now calls renderProjection() so member switching works across all pages

## 2.7 Wealth Projector (NEW v4.1)

### Dashboard Card (1Y fixed)
- Shows: Estimated NW (1Y), After Tax, Inflation Adjusted
- Mini type breakdown: current → projected per investment type
- "Explore →" button navigates to full Wealth Projector page
- Respects currentMember — recalculates when member changes
- Protected with try-catch so errors in preceding dashboard functions don't prevent it from rendering

### Full Analytics Page
- **Time Horizon:** 1Y / 3Y / 5Y / 10Y / 15Y / 20Y pills
- **Editable Inputs:**
  - Inflation Rate % (default 6%)
  - Gold Growth % (default 8%)
  - Expected Rate of Return % (optional override)
- **Member Pills:** Same family switching as dashboard
- **Summary Tiles:** Estimated NW, After Tax, Inflation Adjusted, Real Value (tax + inflation)
- **Type Breakdown:** Current → Projected per investment type with growth %
- **Year-by-Year Table:**
  - Desktop: 7 columns (Year, Value, Growth, Tax, After Tax, Inflation Adj., Real Value)
  - Mobile: 5 columns (Year, Value, Tax, After Tax, Real Value)

### Projection Logic Per Type

| Type | Default Rate | Formula |
|------|-------------|---------|
| Stocks | CAGR from history or 12% | val × (1 + cagr)^years |
| SIP / ELSS | Stored rate or 12% | Corpus growth + FV of monthly SIP with annual step-up |
| RD | Stored rate or 7% | Monthly deposits compounded monthly |
| FD | Stored rate or 7% | Annual compound interest |
| PPF | Stored rate or 7.1% | Annual compound (tax exempt) |
| NPS | Stored rate or 10% | Annual compound (60% exempt) |
| Gold | User-set gold rate or 8% | val × (1 + rate)^years |
| Crypto/Land/Others | N/A | Flat (no projection) |

### Override Rate
- When "Expected Rate of Return %" is filled (non-zero): ALL types use that rate
- SIP/ELSS still factors in monthly contributions + step-up at the override rate
- RD still factors in monthly deposits at the override rate
- When blank/zero: each type uses its own rate per table above

### Tax Calculation
- Uses getTaxRules(type, holdingDays) with projected holding period
- PPF: Fully exempt
- NPS: 60% exempt
- Equity: LTCG 12.5% above ₹1.25L after 1Y
- FD/RD: Taxed at slab rate (approximated 20%)
- Gold: LTCG after 2Y at 12.5%
- Crypto: Flat 30%

## 2.8 Insurance (Updated v4.1)

### Policy Fields
- Policy Name, Type, Company, Sum Assured, Premium Amount
- Premium Frequency: Annually / Half-Yearly / Quarterly / Monthly
- Status: Active / Lapsed
- **Premium Due Day** (1st–31st, optional — enables alerts) ← NEW
- **Premium Due Month** (Jan–Dec, for yearly/half-yearly) ← NEW

### Premium Alert Logic (3-day window)
- Fires 3 days before premium due date (not 7 days)
- Checks frequency to determine which months the premium falls in:
  - Monthly: checks current month always
  - Quarterly: checks if current month matches any quarter from due month
  - Half-Yearly: checks due month and due month + 6
  - Yearly: checks only the due month
- Alert format: "🛡️ LIC Premium Due — ₹15,000/yr — Tomorrow (15th Mar)"

### Insurance Score
- Sum of active policy type weights. Maximum = 100.
- term_life: 25, health: 25, accidental: 15, critical_illness: 10, vehicle: 10, home: 5, child_plan: 5, endowment: 3, travel: 2, others: 0
- Grades: ≥90 Excellent, ≥70 Good, ≥50 Fair, <50 Under-Insured

## 2.9 Tax Calculator

| Asset Class | STCG (< threshold) | LTCG (≥ threshold) | Threshold |
|-------------|--------------------|--------------------|-----------|
| Equity (Stocks/SIP/ELSS) | 20% flat | 12.5% above ₹1.25L | 1 year |
| Debt (FD/RD/Bonds) | Slab rate | Slab rate | N/A |
| PPF | Exempt | Exempt | N/A |
| NPS | 60% exempt, 40% slab | Same | N/A |
| Gold / Land | Slab rate | 12.5% above ₹1.25L | 2 years |
| Crypto | 30% flat | 30% flat | N/A |

## 2.10 Wealth Score (0–100)

| Component | Max Points | Formula |
|-----------|-----------|---------|
| Emergency Fund | 15 | min(15, liquidAssets/monthlySpend/6 × 15) |
| Savings Rate | 15 | min(15, savingsRate/30 × 15) |
| Diversification | 15 | min(15, numAssetBuckets × 4) |
| Has Investments | 5 | +5 if portfolio non-empty |
| Portfolio Returns | 15 | min(15, max(0, (retPct+10)/20 × 15)) |
| Data Completeness | 6 | +3 expenses, +3 income |
| Goal Progress | 10 | min(10, avgCompletion/100 × 10) |
| Insurance Score | 10 | min(10, insScore/100 × 10) |

Grades: ≥85 Excellent (green), ≥70 Good (blue), ≥50 Fair (yellow), <50 Needs Work (red)

## 2.11 Smart Alerts (generateAlerts)

| Alert Type | Window | Priority |
|-----------|--------|----------|
| SIP/RD due | Next 7 days | 0 (today), 1 (upcoming) |
| SIP/RD overdue | Last 3 days | 0 |
| Payment reminder due | Next 7 days | 0-1 |
| Payment reminder overdue | Last 3 days | 0 |
| Insurance premium due | Next 3 days (per frequency) | 0-1 |
| FD/RD maturity approaching | Within 30 days | 0-2 |
| FD/RD matured | Past maturity | 0 |
| Stock near 52W high | Within 2% | 2 |
| Stock near 52W low | Within 2% | 2 |
| Exit signal — SELL | Always | 0 |
| No term life insurance | Always | 3 |
| No health insurance | Always | 3 |

## 2.12 Exit Signal Logic

| Condition (checked in order) | Signal | Reason |
|------------------------------|--------|--------|
| retPct >= targetReturn (user-set) | 🔴 SELL | Hit X% target |
| retPct <= −stopLoss (user-set) | 🔴 SELL | Breached −X% stop loss |
| FD/RD maturityDate in the past | 🔴 SELL | Matured — reinvest |
| livePrice ≤ fiftyTwoLow × 1.05 | 🟡 REVIEW | Near 52-week low |
| maturityDate within 30 days | 🟡 REVIEW | Maturity approaching |
| Equity held < 365 days (STCG) | 🟡 REVIEW | STCG applicable |
| None of above | 🟢 HOLD | Continue holding |

## 2.13 KPI Page (8 Indicators)

| KPI | Range | Formula |
|-----|-------|---------|
| CAGR | % | (NW/Invested)^(12/currentMonth) − 1 |
| Total Return % | % | (NW − Invested) / Invested × 100 |
| Savings Rate | % | (income − expenses) / income × 100 |
| Emergency Fund | Months | (FD+RD value) ÷ monthly expenses |
| Equity % | % | Equity bucket ÷ NW × 100 |
| Debt % | % | Debt bucket ÷ NW × 100 |
| Insurance Score | 0–100 | Sum of active policy type weights |
| Goal Progress | % | Average of (current/target × 100) |

## 2.14 ValeurBot AI Assistant

**Local Mode (default, offline):** Rule-based engine — 40+ query patterns covering portfolio, XIRR, allocation, SIP, insurance, expenses, emergency fund, CAGR, goals, dividends, exit signals, FIRE, rebalancing, tax saving

**Gemini Mode (optional):** Connects to Google Gemini API using user's own key. buildPortfolioContext() sends full portfolio summary. User's data sent to Google — opt-in only.

**Voice Input:** Web Speech API (en-IN), Chrome/Edge only. Fallback toast for unsupported browsers.

## 2.15 PWA & Auto-Update (Updated v4.1)

- Installable on Android (native prompt) and iOS (Add to Home Screen)
- Offline capable — all non-live features work without internet
- **Auto-update system (NEW):**
  - reg.update() forces SW check on every page load
  - HTML files fetched with { cache: "no-cache" } to bypass CDN
  - skipWaiting() + clients.claim() — instant activation
  - updatefound + controllerchange — shows "🔄 Updating..." toast, auto-reloads
  - Result: users never need to manually clear cache

## 2.16 Data Export & Import

**Export:** Downloads complete state as valeurfin-YYYY-MM-DD.json
**Import:** File picker → validation (requires user, user.name, investments array) → confirm dialog → replaces all data
**CSV Import (Stocks):** Paste broker CSV → auto-detects Groww/Zerodha/AngelOne/Kite format → preview → confirm
**CSV Import (MF):** Paste CAMS/KFintech CAS statement → parses fund names, units, NAV → preview → confirm

## 2.17 Security & Privacy

- Optional 4-digit PIN lock (stored Base64-encoded)
- 3 wrong attempts → 30-second cooldown
- Security question backup
- Sign Out: hides dashboard, preserves data
- Wipe All: deletes from all 4 storage layers
- Delete Account: export-first option or immediate delete
- Zero external data collection — only stock symbols sent to Yahoo Finance

## 2.18 Onboarding (4 Steps)

| Step | Content | Validation |
|------|---------|-----------|
| 1 | Name + Age | Name required |
| 2 | Mode: Individual or Family + member add | Mode required |
| 3 | Optional PIN (4 digits) + Security Q&A | PIN must be 4 digits |
| 4 | Completion — "Start Without PIN" or "Set PIN & Start" | Calls obFinish() |

---

# SECTION 3 — TECHNICAL SPECIFICATION

## 3.1 Technology Stack

| Layer | Technology | Notes |
|-------|-----------|-------|
| Language | Vanilla JavaScript (ES5 var/function) | No ES6 classes, no modules, no build step |
| UI | HTML5 + CSS3 | Custom design system, 50+ CSS variables |
| Fonts | Inter (Google Fonts), system-ui fallback | |
| Storage Primary | IndexedDB (DB: ValeurFinDB, Store: appState) | Async, survives browser close |
| Storage Secondary | localStorage (key: vf_state) | Sync fallback |
| Storage Tertiary | sessionStorage (key: vf_state_session) | Lost on tab close |
| Storage Quaternary | Cookie (key: vf_state, truncated 4KB) | Last resort |
| Live Prices | Yahoo Finance v8 chart API | 5 CORS proxy fallback chain |
| MF NAV | mfapi.in public API | CORS-proxied |
| Gold Price | gold-api.com | Direct (CORS-friendly) |
| AI Local | Rule-based ValeurBot | 40+ patterns, offline |
| AI Cloud | Google Gemini API | User's own key, opt-in |
| PWA | Service Worker + manifest.json | Network-First strategy |
| Hosting | GitHub Pages | Static, CDN-backed, HTTPS |

## 3.2 File Structure

```
valeurfin/
├── index.html              ← Desktop app (5,573 lines, 269 functions)
├── valeurfin-mobile.html   ← Mobile app (3,861 lines, 240 functions)
├── sw.js                   ← Service Worker (154 lines, Network-First)
├── manifest.json           ← PWA manifest for desktop
├── manifest-mobile.json    ← PWA manifest for mobile
└── logo.png                ← App icon (used by PWA + favicons)
```

## 3.3 Data Model

### 3.3.1 Root State Object (S)

```javascript
S = {
  version:       4.0,
  user:          { name, age, gender, location, pin, hasPin,
                   mode, securityQ, securityA },  // mode: 'individual'|'family'
  family:        [{ id, name, relation, age }],
  investments:   [ Investment ],
  expenses:      [{ id, label, category, amount, frequency, owner, createdAt }],
  budgets:       { category: amount },
  income:        [{ id, label, category, amount, frequency, owner, createdAt }],
  reminders:     [{ id, label, remType, amount, frequency, dueDate, createdAt }],
  insurance:     [{ id, label, insType, company, sumAssured, premium,
                    premFreq, premDueDate, premDueMonth, status, owner, createdAt }],
  dividends:     [{ id, stock, sym, date, dps, qty, totalDiv, fy, createdAt }],
  goals:         [{ id, name, target, current, deadline, icon, createdAt }],
  snapshots:     [{ month, nw, invested }],
  transactions:  [{ id, date, type, label, amount, icon }],  // capped at 500
  currentMonth:  0,
  totalContrib:  0,
  totalReturns:  0,
  lastProcessed: null,
  lastOpened:    null,
  theme:        'dark',
  aiMode:       'local',
  geminiKey:    '',
  createdAt:     Date.now()
}
```

### 3.3.2 Investment Object (30+ fields)

```javascript
Investment = {
  id:            uid(),
  type:          'SIP'|'Stocks'|'FD'|'RD'|'PPF'|'NPS'|'Gold'|'Crypto'|
                 'Land'|'ELSS'|'Bonds'|'Others',
  label:         string,
  platform:      string,
  bucket:        'Equity'|'Debt'|'Hybrid'|'Alternatives',
  owner:         'self' | familyMemberId,
  started:       'YYYY-MM-DD',
  
  // Core financials
  invested:      number,
  value:         number,
  returns:       number,
  returnRate:    number,     // % p.a. (FD/PPF/NPS)
  
  // Lot-based (Stocks/ETF)
  lots:          [{ id, date, qty, price }],
  qty:           number,
  avgPrice:      number,
  nseSymbol:     string,
  sector:        string,
  
  // Live price (fetched)
  livePrice:     number|null,
  liveValue:     number|null,
  dayChange:     number|null,
  dayChangePct:  number|null,
  fiftyTwoHigh:  number|null,
  fiftyTwoLow:   number|null,
  
  // MF specific
  schemeCode:    string,
  totalUnits:    number,
  currentNAV:    number,
  
  // Monthly (SIP/RD)
  monthly:       number,
  dueDate:       string,
  stepUp:        number,
  stepUpFrom:    number,
  lastSIPMonth:  string,
  
  // SWP
  swpAmount:     number,
  swpStartDate:  string,
  lastSWPMonth:  string,
  
  // Gold
  grams:         number,
  goldPurity:    number,     // 24/22/18/0
  
  // Dividends
  divCache:      [],
  divCacheDate:  number,     // 0=never, 1=proxy failed, >1=timestamp
  
  // Risk
  targetReturn:  number|null,
  stopLoss:      number|null,
  maturityDate:  string,
  
  createdAt:     number
}
```

## 3.4 Storage Architecture — Quad Fallback

```
saveS() flow:
  1. Compute JSON hash — if matches last saved hash, skip (no-op)
  2. Write to IndexedDB (async, primary)
  3. Write to localStorage (sync, secondary)
  4. Write to sessionStorage (sync, tertiary)
  5. Write truncated to Cookie (4KB limit, quaternary)

loadS() flow:
  1. Try IndexedDB → if found, use it
  2. Wait 600ms, retry IndexedDB (cold-start race condition)
  3. Try localStorage
  4. Try sessionStorage
  5. Try Cookie (parseJSON of truncated data)
  6. All fail → return null (triggers onboarding)
```

## 3.5 getInvValue() — Value Calculation Engine

```javascript
function getInvValue(inv) {
  // Path 1: MF/ELSS — units × NAV
  if ((type === 'SIP' || type === 'ELSS') && inv.totalUnits && inv.currentNAV)
    return inv.totalUnits * inv.currentNAV;
  
  // Path 2: Stocks with lots + live price
  if (invHasLots(inv) && inv.livePrice) return getInvQty(inv) * inv.livePrice;
  
  // Path 3: FD/PPF — compound annual
  if ((type === 'FD' || type === 'PPF') && inv.returnRate > 0 && inv.started)
    return invested × (1 + rate/100)^years;
  
  // Path 4: RD — monthly compound
  if (type === 'RD' && inv.monthly > 0)
    for each month: total += monthly × (1 + monthlyRate)^(months-n+1);
  
  // Path 5: Gold — grams × live gold price
  if (type === 'Gold' && inv.grams > 0 && goldPriceData)
    return grams × pricePerGram(purity);
  
  // Fallback
  return inv.liveValue || inv.value || 0;
}
```

## 3.6 CORS Proxy Chain

```javascript
var CORS_PROXIES = [
  'https://prices.valeurfin.workers.dev/?url=',  // Custom Cloudflare Worker (fastest)
  'https://corsproxy.io/?',                        // Free proxy service
  'https://api.allorigins.win/raw?url=',           // Fallback 1
  'https://api.codetabs.com/v1/proxy?quest=',      // Fallback 2
  'https://thingproxy.freeboard.io/fetch/'          // Fallback 3
];
```

Each fetch tries proxies in order with 8-second timeout per attempt. If all fail, returns null.

## 3.7 Wealth Projector Engine

### calcProjectedValue(inv, years, goldRate, overrideRate)

```
If overrideRate > 0:
  - SIP/ELSS: corpus × (1+rate)^years + FV of monthly contributions with step-up
  - RD: monthly compound at override rate
  - All others: val × (1+overrideRate)^years

Else (individual rates):
  - Stocks: val × (1 + CAGR)^years (CAGR from history, capped -50% to +100%, default 12%)
  - SIP/ELSS: corpus growth + FV of SIP with step-up (monthly compound)
  - RD: monthly deposits compounded
  - FD: annual compound at stored rate
  - PPF: annual compound at stored rate (default 7.1%)
  - NPS: annual compound at stored rate (default 10%)
  - Gold: val × (1 + goldRate)^years
  - Others: flat (no projection)
```

### calcProjectedTax(inv, gain, years)
```
Uses getTaxRules(type, 365 * years):
  - PPF: 0 (exempt)
  - NPS: gain × 0 (simplified as exempt in projector)
  - Equity LTCG: max(0, gain − 125000) × 12.5%
  - Equity STCG: gain × 20%
  - FD/RD: gain × 20% (slab approximation)
  - Crypto: gain × 30%
  - Gold LTCG: max(0, gain − 125000) × 12.5%
```

## 3.8 Service Worker (sw.js)

```
Strategy: Network-First

Install:
  - Cache core files (index.html, mobile.html, manifest.json)
  - skipWaiting() — don't wait for old SW to expire

Activate:
  - Delete all old caches except current CACHE_NAME
  - clients.claim() — take control immediately

Fetch:
  - Skip: non-GET, API endpoints (Yahoo, mfapi, gold-api, etc.)
  - HTML files: fetch with { cache: 'no-cache' } to bypass CDN
  - Other files: normal network fetch
  - On success: clone and cache for offline use
  - On failure: serve from cache
  - Nothing cached: show offline page

Message:
  - SKIP_WAITING: forces waiting SW to activate
  - CACHE_URLS: pre-caches specified URLs
```

### Auto-Update (in HTML files)
```javascript
navigator.serviceWorker.register('sw.js').then(function(reg) {
  reg.update();  // Force check on every page load
  reg.addEventListener('updatefound', function() {
    // New SW found → wait for activation → auto-reload
    newWorker.addEventListener('statechange', function() {
      if (newWorker.state === 'activated') {
        toast('🔄 App updated!');
        setTimeout(function() { window.location.reload(); }, 1500);
      }
    });
  });
});
// Also reload on controllerchange (another tab triggered update)
navigator.serviceWorker.addEventListener('controllerchange', function() {
  window.location.reload();
});
```

## 3.9 Constants & Configuration

| Constant | Value | Purpose |
|----------|-------|---------|
| AUTO_REFRESH_INTERVAL | 5 min (300,000 ms) | Stock price refresh during market hours |
| MF_NAV_STALE_MS | 8 hours | MF NAV cache TTL |
| GOLD_STALE_MS | 4 hours | Gold price cache TTL |
| DIV_CACHE_MS | 24 hours | Dividend history cache TTL |
| DB_NAME | 'ValeurFinDB' | IndexedDB database name |
| LS_KEY | 'vf_state' | localStorage key |
| CACHE_NAME | 'valeurfin-v5i' | SW cache version |
| STOCK_DB | 435 entries | Local NSE stock database |
| LOCAL_MF_DB | 120+ entries | Local mutual fund database |
| CORS_PROXIES | 5 entries | Yahoo Finance proxy chain |

## 3.10 renderAll() — Render Orchestration

```javascript
function renderAll() {
  renderFamilyDD();  // Sidebar family dropdown
  rDash();           // Dashboard (calls rDashEstNW, rDashFIRE, etc.)
  rInv();            // Investments table
  rExp();            // Expenses list
  rIncome();         // Income list
  rReminders();      // Reminders
  rGoals();          // Goals with progress
  rInsurance();      // Insurance + score ring
  rKPI();            // KPI tiles
  rDividends();      // Dividend table
  rWhatIf();         // What-If results
  rLog();            // Transaction log
  rFamily();         // Family member list
  rSecurity();       // Security page
  renderAddForm();   // Add Investment form
  rBotPageChips();   // Bot suggested prompts
  try { renderProjection(); } catch(e) {}  // Wealth Projector (protected)
  // Update topbar date, avatar, mode display
}
```

---

# SECTION 4 — KT (KNOWLEDGE TRANSFER) DOCUMENT

## 4.1 Developer Onboarding

### Prerequisites
- Text editor (VS Code recommended)
- Git + GitHub account
- Chrome DevTools for debugging
- No build tools, no npm, no webpack — files are deployed as-is

### Quick Start
1. Clone repo: `git clone https://github.com/valeurfin-app/valeurfin`
2. Open `index.html` in Chrome (or use Live Server extension)
3. Complete onboarding flow (name, mode, optional PIN)
4. Add a test stock (e.g., HDFC Bank, symbol HDFCBANK)
5. Click 🔄 to fetch live prices

### Code Structure
Both HTML files follow the same structure:
```
<!DOCTYPE html>
<html>
<head>
  <meta tags>
  <style> /* 600+ lines of CSS */ </style>
</head>
<body>
  <!-- 500+ lines of HTML: pages, modals, overlays -->
  <script>
    // Line 1-100: Constants (INV_TYPES, STOCK_DB, etc.)
    // Line 100-200: Helper functions (fmt, uid, ordinal, etc.)
    // Line 200-300: Storage (openDB, saveS, loadS)
    // Line 300-500: Onboarding flow
    // Line 500-800: Navigation, family switching, member pills
    // Line 800-1200: Dashboard rendering (rDash + sub-functions)
    // Line 1200-1600: Investment rendering + Add form + Edit modal
    // Line 1600-1800: MF Search, Stock Search
    // Line 1800-2000: Expenses, Income, Reminders, Goals, Insurance
    // Line 2000-2200: Dividends (auto-fetch + manual)
    // Line 2200-2400: Tax Calculator, Exit Signals, KPIs
    // Line 2400-2600: Market Pulse, News, Indices
    // Line 2600-2800: ValeurBot (local + Gemini)
    // Line 2800-3000: Auto-refresh, price fetching
    // Line 3000-3200: Wealth Projector engine
    // Line 3200-3400: SWP, Import CSV, What-If
    // Line 3400-3500: Alerts, Security, Boot, InitApp
    // Line 3500+: SW registration, auto-update
  </script>
</body>
</html>
```

## 4.2 Function Reference — Core Lifecycle

| Function | File | Purpose | Called By |
|----------|------|---------|-----------|
| boot() | Both | Opens IDB, loads state, shows lock/onboard/dashboard | DOMContentLoaded |
| initApp() | Both | Applies theme, renders all, starts auto-refresh, fetches prices | After boot/unlock |
| renderAll() | Both | Calls all page render functions | After any data change |
| saveS() | Both | Saves S to all 4 storage layers with hash guard | After every state mutation |
| loadS() | Both | Loads from IDB → localStorage → sessionStorage → cookie | During boot |
| defaultState() | Both | Returns fresh empty state object | During first onboarding |

## 4.3 Function Reference — Dashboard

| Function | Purpose | Notes |
|----------|---------|-------|
| rDash() | Main dashboard renderer | Calls 12+ sub-functions, protected with try-catch |
| rDashEstNW() | Wealth Projector dashboard card | 1Y projection, uses filterByMember |
| rDashFIRE(nw, mSpend) | FIRE progress card | FI number = expenses × 12 × 25 |
| rDashCashFlow(inc, exp, sip) | Cash flow summary | Income vs expenses + SIP |
| rDashEvents() | Upcoming events | SIP dues, insurance, maturity this month |
| rDashTips(nw, inv, ...) | AI Insights | Up to 5 rule-based tips |
| rDashExitCues(inv, nw) | Exit signal summary | Top sell/review signals |
| rDashAlerts() | Recent alerts | Last 5 from alertList |
| rDashHoldings() | Top holdings | Sorted by value, top 5 |
| rDonut() | Asset allocation donut | Equity/Debt/Hybrid/Alternatives |
| rSectorDonut() | Sector allocation donut | Banking/IT/FMCG/etc. |
| renderMemberPills(id) | Family member buttons | Also used on Wealth Projector page |
| rFamilyOverview() | Per-member net worth cards | Only shows in "All" view |

## 4.4 Function Reference — Investment Management

| Function | Purpose |
|----------|---------|
| addInvestment() | Reads form, creates investment object, saves |
| buildAddFields() | Generates type-specific form HTML based on selectedInvType |
| openEditInv(id) | Opens edit modal with pre-filled fields |
| saveEdit() | Saves edited investment |
| quickDeleteInv(id) | Deletes investment with confirm |
| syncInvFromLots(inv) | Recalculates qty, avgPrice, invested from lots array |
| recalcStockInvested() | Auto: qty × buyPrice → invested field |
| recalcStockCurrentValue() | Auto: qty × stockPrice → current value field |
| recalcStockReturn() | Auto: XIRR calculation → return display |
| filterInv() | Filters investment table by type pill selection |

## 4.5 Function Reference — Fetch & Live Data

| Function | Trigger | TTL | Returns |
|----------|---------|-----|---------|
| refreshAll() | Auto-refresh, manual 🔄 | 5 min | Calls all fetch functions |
| fetchLivePrices() | refreshAll() | Every call | Updates livePrice, liveValue, dayChange |
| fetchStockPrice(sym) | fetchLivePrices() | Every call | { price, change, changePct, 52W } |
| fetchMFNavs() | refreshAll(), initApp() | 8 hours | Updates currentNAV |
| fetchGoldPrice() | refreshAll(), initApp() | 4 hours | Updates goldPriceData global |
| fetchIndices() | refreshAll() | Every call | NIFTY, SENSEX, BANK NIFTY |
| fetchDividendHistory(sym) | loadAllDividends() | 24 hours | Dividend entries array |
| fetchMarketNews() | refreshAll() | Every call | RSS news items |
| startAutoRefresh() | initApp() | — | Starts 60s watchdog → 5min refresh |

## 4.6 Function Reference — Wealth Projector

| Function | Purpose |
|----------|---------|
| setProjectionHorizon(btn, years) | Sets _projHorizon, re-renders |
| calcProjectedValue(inv, years, goldRate, overrideRate) | Projects single investment value |
| calcProjectedTax(inv, gain, years) | Estimates tax on projected gains |
| renderProjection() | Full projector page: pills, summary, breakdown, table |
| rDashEstNW() | Dashboard card version (1Y fixed, compact) |

## 4.7 Common Bug Fix Patterns

### "Nothing happens when I click Save"
- Usually a silent JS error. Open F12 → Console → look for red errors
- Most common: getElementById returns null for a field that doesn't exist in the current form
- Fix: guard with `(document.getElementById('x') || {}).value`

### "Investments show but Net Worth is ₹0"
- getInvValue() returning 0 for all investments
- Check: does the investment have the right fields? (qty for stocks, totalUnits for MF, invested for FD)
- For stocks: need nseSymbol + successful price fetch

### "Family dropdown doesn't show"
- Check S.user.mode in console — must be "family" not "individual"
- All family UI checks ONLY S.user.mode, never S.family.length

### "Prices not fetching"
- All CORS proxies may be down — check console for 403/503 errors
- Yahoo Finance may have changed API format
- Try: `fetchStockPrice('HDFCBANK')` in console to debug

### "Service Worker serving old files"
- sw.js has auto-update but CDN may cache for up to 10 min
- Nuclear option: DevTools → Application → Service Workers → Unregister → Hard Refresh

## 4.8 Deployment Checklist

1. ☐ Increment CACHE_NAME in sw.js (e.g., v5i → v5j)
2. ☐ Update APP_VERSION in both HTML files
3. ☐ Run syntax check: `node -e "new Function(code)"` on all script blocks
4. ☐ Test all 12 investment type forms (especially Stocks, SIP, PPF, NPS, RD)
5. ☐ Test family member switching on dashboard + Wealth Projector
6. ☐ Test auto-refresh during market hours
7. ☐ Push all 3 files: index.html, valeurfin-mobile.html, sw.js
8. ☐ Wait 1–2 minutes for GitHub Pages CDN
9. ☐ Open app — auto-update should trigger "🔄 Updating..." toast
10. ☐ Verify on mobile (phone browser)

## 4.9 External APIs

| API | Purpose | Data Sent | Privacy Impact |
|-----|---------|-----------|----------------|
| Yahoo Finance v8 | Stock prices, 52W, dividends | Stock symbol only | No personal data |
| mfapi.in | MF search, scheme codes, NAV | Search query only | No personal data |
| gold-api.com | Gold price INR | None | No personal data |
| CORS Proxies (5) | Bypass browser CORS | API URL only | No personal data |
| Google Gemini | AI chat (optional) | Portfolio summary | Opt-in, user's own key |
| TradingView | Market heatmap widget | None | Public widget |
| RSS feeds | Market news | None | Public feeds |

## 4.10 Glossary

| Term | Definition |
|------|-----------|
| XIRR | Extended Internal Rate of Return — annualised return for irregular cash flows |
| LTCG | Long-Term Capital Gains — equity > 1Y, taxed at 12.5% above ₹1.25L |
| STCG | Short-Term Capital Gains — equity < 1Y, taxed at 20% flat |
| SIP | Systematic Investment Plan — fixed monthly MF investment |
| SWP | Systematic Withdrawal Plan — fixed monthly withdrawal |
| ELSS | Equity Linked Savings Scheme — tax-saving MF, 3Y lock-in |
| NAV | Net Asset Value — per-unit MF price |
| DPS | Dividend Per Share |
| Lot | Single purchase transaction (date + qty + price) |
| PWA | Progressive Web App — installable, offline-capable web app |
| IDB | IndexedDB — browser database, primary storage |
| NSE/BSE | National/Bombay Stock Exchange |
| FIRE | Financial Independence, Retire Early |
| CAGR | Compound Annual Growth Rate |
| FY | Financial Year (April–March in India) |

---

END OF DOCUMENT

ValeurFin v4.1 • April 2026 • valeurfin-app.github.io/valeurfin
